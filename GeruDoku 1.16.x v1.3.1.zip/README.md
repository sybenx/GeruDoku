![image](https://i.vgy.me/9GZFdq.png)

# GeruDoku
1.14, 1.15, 1.16 GeruDoku - Minecraft
___
__Download:__

__[Latest version](https://github.com/Syberiyxx/GeruDoku/releases/latest)__

__[All Releases](https://github.com/Syberiyxx/gerudoku/releases/)__
___
__[Download foundational pack: (1.13) Gerudoku Legacy](http://www.mediafire.com/file/8w1a57na5k5yyc8/%25281.13%2529_Gerudoku_Faithful_32x.zip/file)__ 
___
[This thread](https://www.minecraftforum.net/forums/mapping-and-modding-java-edition/resource-packs/2895569-gerudoku-legacy-thread-1-14-coming-soon-32x) is the last work I could find on this texture pack. I want to maintain it so we can remember the good old days of the Yogscast Minecraft Survival series. [This is a recreation](https://drive.google.com/open?id=1k9g6cpa7C_hHOdpL9azseGhDW_Gm9NZ4) of part of the Yogscast world I found online, I'm unaware of any better recreations.
___
I've updated it to work with 1.16. I don't plan on creating art for anything that's missing. I'm maintaining it so that it works with the current version of Minecraft. 
